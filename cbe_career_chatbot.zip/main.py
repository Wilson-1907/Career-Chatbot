from fastapi import FastAPI
from routers import auth, chat, games, admin

app = FastAPI(title="CBE Career Chatbot API")

app.include_router(auth.router, prefix="/auth", tags=["Auth"])
app.include_router(chat.router, prefix="/chat", tags=["Chat"])
app.include_router(games.router, prefix="/games", tags=["Games"])
app.include_router(admin.router, prefix="/admin", tags=["Admin"])

@app.get("/")
def root():
    return {"message": "Welcome to the CBE Career Chatbot API"}
