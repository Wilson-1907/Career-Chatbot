from fastapi import APIRouter

router = APIRouter()

@router.get('/metrics')
async def metrics():
    # TODO: Aggregate anonymized data
    return {"metrics": "placeholder"}

@router.post('/feedback')
async def feedback(payload: dict):
    # TODO: Store feedback
    return {"ok": True}
