from fastapi import APIRouter

router = APIRouter()

@router.post('/message')
async def message(payload: dict):
    # TODO: Integrate AI service here
    return {"reply": "Hello — this is a chatbot placeholder."}

@router.get('/history')
async def history(user_id: str, limit: int = 10):
    # TODO: Fetch from database
    return {"history": []}
