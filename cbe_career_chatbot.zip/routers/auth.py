from fastapi import APIRouter

router = APIRouter()

@router.post('/social-login')
async def social_login(payload: dict):
    # TODO: Verify provider token, return JWT
    return {"message": "Social login placeholder"}

@router.post('/anonymous')
async def anonymous_login():
    # TODO: Generate anonymous token
    return {"token": "anon-token-placeholder"}

@router.post('/refresh')
async def refresh_token():
    # TODO: Refresh JWT
    return {"token": "refreshed-token-placeholder"}
