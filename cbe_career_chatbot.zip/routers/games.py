from fastapi import APIRouter

router = APIRouter()

@router.get('/list')
async def list_games():
    return [
        {"id": "quiz_race", "name": "Quiz Race", "description": "Timed career quiz challenge"}
    ]

@router.post('/{game_id}/start')
async def start_game(game_id: str, user_id: str = None):
    # TODO: Store session in Redis
    return {"session_id": "session-placeholder"}

@router.post('/{game_id}/submit')
async def submit_game(game_id: str, payload: dict):
    # TODO: Store results in DB
    return {"ok": True}
